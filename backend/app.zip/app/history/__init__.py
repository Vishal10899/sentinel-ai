"""Request history storage."""
